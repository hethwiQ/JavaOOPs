package PowerBillingSystem;

public class CommercialRates extends Rates {
    public void getRate() {
        rate = 7.50;
    }

}
