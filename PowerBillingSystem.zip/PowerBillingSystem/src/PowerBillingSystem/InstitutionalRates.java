package PowerBillingSystem;

public class InstitutionalRates extends Rates {
    public void getRate()
    {
        rate=5.50;
    }

}

