package PowerBillingSystem;

public class DomesticRates extends Rates {
    public void getRate() {
        rate = 3.50;
    }

}
